package accesoDatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.TreeSet;

import auxiliares.LeeProperties;
import logicaRefrescos.Deposito;
import logicaRefrescos.Dispensador;

public class AccesoJDBC implements I_Acceso_Datos {

	private String driver, urlbd, user, password; // Datos de la conexion
	private Connection conn1;

	public AccesoJDBC() {
		System.out.println("ACCESO A DATOS - Acceso JDBC");

		try {
			HashMap<String, String> datosConexion;

			LeeProperties properties = new LeeProperties("Ficheros/config/accesoJDBC.properties");
			datosConexion = properties.getHash();

			driver = datosConexion.get("driver");
			urlbd = datosConexion.get("urlbd");
			user = datosConexion.get("user");
			password = datosConexion.get("password");
			conn1 = null;

			Class.forName(driver);
			conn1 = DriverManager.getConnection(urlbd, user, password);
			if (conn1 != null) {
				System.out.println("Conectado a la base de datos");
			}

		} catch (ClassNotFoundException e1) {
			System.out.println("ERROR: No Conectado a la base de datos. No se ha encontrado el driver de conexion");
			// e1.printStackTrace();
			System.out.println("No se ha podido inicializar la maquina\n Finaliza la ejecucion");
			System.exit(1);
		} catch (SQLException e) {
			System.out.println("ERROR: No se ha podido conectar con la base de datos");
			System.out.println(e.getMessage());
			// e.printStackTrace();
			System.out.println("No se ha podido inicializar la maquina\n Finaliza la ejecucion");
			System.exit(1);
		}
	}

	public int cerrarConexion() {
		try {
			conn1.close();
			System.out.println("Cerrada conexion");
			return 0;
		} catch (Exception e) {
			System.out.println("ERROR: No se ha cerrado corretamente");
			e.printStackTrace();
			return -1;
		}
	}

	@Override
	public HashMap<Integer, Deposito> obtenerDepositos() {

		HashMap<Integer, Deposito> de = new HashMap<>();
		String query = "SELECT * from depositos";

		try {
			PreparedStatement ps = conn1.prepareStatement(query);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				String nombreMoneda = rs.getString("nombre");
				int valor = rs.getInt("valor");
				int cantidad = rs.getInt("cantidad");
				Deposito dep = new Deposito(nombreMoneda, valor, cantidad);

				de.put(valor, dep);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return de;

	}

	@Override
	public HashMap<String, Dispensador> obtenerDispensadores() {
		HashMap<String, Dispensador> dis = new HashMap<>();
		String query = "SELECT * from dispensadores";

		try {
			PreparedStatement ps = conn1.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String clave = rs.getString("clave");
				String nombreProducto = rs.getString("nombre");
				int precio = rs.getInt("precio");
				int cantidad = rs.getInt("cantidad");

				Dispensador dispen = new Dispensador(clave, nombreProducto, precio, cantidad);
				dis.put(clave, dispen);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dis;
	}

	@Override
	public boolean guardarDepositos(HashMap<Integer, Deposito> depositos) {
		boolean todoOK = false;
		String queryDelete = "DELETE FROM depositos";
		String query = "INSERT INTO depositos (id,nombre,valor,cantidad) values (?,?,?,?)";

		try (Statement s = conn1.createStatement()) {

			s.executeUpdate(queryDelete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try (PreparedStatement p = conn1.prepareStatement(query)) {
			for (Entry<Integer, Deposito> depo : depositos.entrySet()) {

				Deposito de = depo.getValue();
				p.setInt(1, depo.getKey());
				p.setString(2, de.getNombreMoneda());
				p.setInt(3, de.getValor());
				p.setInt(4, de.getCantidad());
				p.executeUpdate();
			}
			todoOK = true;

		} catch (SQLException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return todoOK;
	}

	@Override
	public boolean guardarDispensadores(HashMap<String, Dispensador> dispensadores) {
		boolean todoOK = false;
		String queryDelete = "DELETE FROM dispensadores";
		String query = "INSERT INTO dispensadores (id,clave,nombre,precio,cantidad) values (?,?,?,?,?)";
		try (Statement s = conn1.createStatement()) {

			s.executeUpdate(queryDelete);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (PreparedStatement p = conn1.prepareStatement(query);) {
			int idContador = 1;
			for (Entry<String, Dispensador> dispen : dispensadores.entrySet()) {

				Dispensador dis = dispen.getValue();
				p.setInt(1, idContador);
				;
				p.setString(2, dis.getClave());
				p.setString(3, dis.getNombreProducto());
				p.setInt(4, dis.getPrecio());
				p.setInt(5, dis.getCantidad());
				p.executeUpdate();
				idContador++;
			}
			todoOK = true;
		} catch (SQLException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return todoOK;
	}

} // Fin de la clase