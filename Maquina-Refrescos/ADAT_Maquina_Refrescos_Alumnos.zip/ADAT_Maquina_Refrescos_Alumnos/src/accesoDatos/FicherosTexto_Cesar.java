package accesoDatos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.TreeSet;

import logicaRefrescos.Deposito;
import logicaRefrescos.Dispensador;

/*
 * Todas los accesos a datos implementan la interfaz de Datos
 */

public class FicherosTexto_Cesar implements I_Acceso_Datos {

	File fDis; // FicheroDispensadores
	File fDep; // FicheroDepositos

	public FicherosTexto_Cesar() {
		System.out.println("ACCESO A DATOS - FICHEROS DE TEXTO");
		// Cargamos los ficheros
		fDep = new File("Ficheros\\datos\\depositos.txt");
		fDis = new File("Ficheros\\datos\\dispensadores.txt");
	}

	@Override
	public HashMap<Integer, Deposito> obtenerDepositos() {

		HashMap<Integer, Deposito> depositosCreados = new HashMap<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fDep));
			String linea;
			while ((linea = br.readLine()) != null) {
				String[] array = linea.strip().split(";");
				String nombre = array[0];
				int valor = Integer.parseInt(array[1]);
				int cantidad = Integer.parseInt(array[2]);

				Deposito d = new Deposito(nombre, valor, cantidad);
				depositosCreados.put(d.getValor(), d);
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace(); // ← añade esto
		}
		return depositosCreados;
	}

	@Override
	public HashMap<String, Dispensador> obtenerDispensadores() {

		HashMap<String, Dispensador> dispensadoresCreados = new HashMap<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fDis));
			String linea;
			while ((linea = br.readLine()) != null) {
				String[] array = linea.strip().split(";");
				String clave = array[0];
				String nombre = array[1];
				int precio = Integer.parseInt(array[2]);
				int cantidad = Integer.parseInt(array[3]);

				Dispensador d = new Dispensador(clave, nombre, precio, cantidad);
				dispensadoresCreados.put(clave, d);
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace(); // ← añade esto
		}
		return dispensadoresCreados;

	}

	@Override
	public boolean guardarDepositos(HashMap<Integer, Deposito> depositos) {

		boolean todoOK = true;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(fDep));
			for (Entry<Integer, Deposito> mapa : depositos.entrySet()) {
				Deposito valor = mapa.getValue();

				bw.write(valor.getNombreMoneda() + ";" + valor.getValor() + ";" + valor.getCantidad() + "\n");

			}
			bw.close();
		} catch (IOException e) {
			todoOK = false;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return todoOK;

	}

	@Override
	public boolean guardarDispensadores(HashMap<String, Dispensador> dispensadores) {

		boolean todoOK = true;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(fDis));
			for (Entry<String, Dispensador> mapa : dispensadores.entrySet()) {
				Dispensador valor = mapa.getValue();

				bw.write(valor.getClave() + ";" + valor.getNombreProducto() + ";" + valor.getPrecio() + ";"
						+ valor.getCantidad() + "\n");

			}
			bw.close();
		} catch (IOException e) {
			todoOK = false;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return todoOK;
	}

} // Fin de la clase