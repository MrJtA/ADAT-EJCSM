package accesoDatos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import logicaRefrescos.Deposito;
import logicaRefrescos.Dispensador;

/*
 * Todas los accesos a datos implementan la interfaz de Datos
 */

public class XmlManager implements I_Acceso_Datos {

	File fDis; // FicheroDispensadores
	File fDep; // FicheroDepositos

	public XmlManager() {
		System.out.println("ACCESO A DATOS - XML");

		// Cargamos los ficheros
		fDep = new File("Ficheros/datos/depositos.xml");
		fDis = new File("Ficheros/datos/dispensadores.xml");

	}

	@Override
	public HashMap<Integer, Deposito> obtenerDepositos() {

		HashMap<Integer, Deposito> depositosCreados = new HashMap<>();

		try {
			// Cargamos el arbol XML a partir del contenido del fichero
			SAXBuilder saxBuilder = new SAXBuilder();
			Document document = saxBuilder.build(fDep);
			Element raizDepositos = document.getRootElement();
			List<Element> lista = raizDepositos.getChildren();
			for (int i = 0; i < lista.size(); i++) {
				Element e = lista.get(i);
				String nombre = e.getChildText("nombre");
				String valor = e.getChildText("valor");
				int valor1 = Integer.parseInt(valor);

				String cantidad = e.getChildText("cantidad");
				int cantidad1 = Integer.parseInt(cantidad);

				Deposito d = new Deposito(nombre, valor1, cantidad1);
				depositosCreados.put(valor1, d);
			}
			// Rellenar a partir de aqu�

		} catch (Exception e) {
			System.out.println("ERROR: No se ha podido conectar con el XML de depositos");
			System.out.println(e.getMessage());
			// e.printStackTrace();
			System.out.println("No se ha podido inicializar la maquina\n Finaliza la ejecucion");
			System.exit(1);
		}

		return depositosCreados;
	}

	@Override
	public HashMap<String, Dispensador> obtenerDispensadores() {

		HashMap<String, Dispensador> dispensadoresCreados = new HashMap<>();

		try {
			// Cargamos el arbol XML a partir del contenido del fichero
			SAXBuilder saxBuilder = new SAXBuilder();
			Document document = saxBuilder.build(fDis);
			Element raizDispensadores = document.getRootElement();
			List<Element> lista = raizDispensadores.getChildren();
			for (int i = 0; i < lista.size(); i++) {
				Element e = lista.get(i);
				String clave = e.getChildText("clave");
				String nombre = e.getChildText("nombreLargo");

				String precio = e.getChildText("precio");
				int precio1 = Integer.parseInt(precio);

				String cantidad = e.getChildText("cantidad");
				int cantidad1 = Integer.parseInt(cantidad);

				Dispensador d = new Dispensador(clave, nombre, precio1, cantidad1);
				dispensadoresCreados.put(clave, d);

			}
			// Rellenar a partir de aqu�

		} catch (Exception e) {
			System.out.println("ERROR: No se ha podido conectar con el XML de dispensadores");
			System.out.println(e.getMessage());
			// e.printStackTrace();
			System.out.println("No se ha podido inicializar la maquina\n Finaliza la ejecucion");
			System.exit(1);
		}

		return dispensadoresCreados;
	}

	@Override
	public boolean guardarDepositos(HashMap<Integer, Deposito> depositos) {

		boolean todoOK = false; // Variable que indica si el almacenamiento de informaci�n termina correctamente
		Element raiz = new Element("depositos");
		Document d = new Document(raiz);

		for (Entry<Integer, Deposito> de : depositos.entrySet()) {
			Deposito deposi = de.getValue();
			Element deposito = new Element("deposito");

			Element nombre = new Element("nombre");
			nombre.setText(deposi.getNombreMoneda());

			Element valor = new Element("valor");
			valor.setText(String.valueOf(deposi.getValor()));

			Element cantidad = new Element("cantidad");
			cantidad.setText(String.valueOf(deposi.getCantidad()));

			deposito.addContent(nombre);
			deposito.addContent(valor);
			deposito.addContent(cantidad);
			raiz.addContent(deposito);
		}
		Format f = Format.getPrettyFormat();
		f.setEncoding("UTF-8");

		// 6. Escribir el documento en el archivo (PASO FALTANTE)
		XMLOutputter xmlOut = new XMLOutputter(f);

		// output() escribe el documento al flujo de salida (en este caso, un archivo)
		try {
			xmlOut.output(d, new FileOutputStream(fDep));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("El archivo XML se ha creado correctamente en: " + fDep);
		todoOK = true;

		return todoOK;

	}

	@Override
	public boolean guardarDispensadores(HashMap<String, Dispensador> dispensadores) {

		boolean todoOK = false; // Variable que indica si el almacenamiento de informaci�n termina correctamente
		Element raiz = new Element("dispensadores");
		Document d = new Document(raiz);

		for (Entry<String, Dispensador> de : dispensadores.entrySet()) {
			Dispensador dispen = de.getValue();
			Element dispensador = new Element("dispensador");

			Element clave = new Element("clave");
			clave.setText(dispen.getClave());

			Element nombreLargo = new Element("nombreLargo");
			nombreLargo.setText(dispen.getNombreProducto());

			Element precio = new Element("precio");
			precio.setText(String.valueOf(dispen.getPrecio()));

			Element cantidad = new Element("cantidad");
			cantidad.setText(String.valueOf(dispen.getCantidad()));

			dispensador.addContent(clave);
			dispensador.addContent(nombreLargo);
			dispensador.addContent(precio);
			dispensador.addContent(cantidad);
			raiz.addContent(dispensador);

		}
		Format f = Format.getPrettyFormat();
		f.setEncoding("UTF-8");

		// 6. Escribir el documento en el archivo (PASO FALTANTE)
		XMLOutputter xmlOut = new XMLOutputter(f);

		// output() escribe el documento al flujo de salida (en este caso, un archivo)
		try {
			xmlOut.output(d, new FileOutputStream(fDis));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("El archivo XML se ha creado correctamente en: " + fDep);
		todoOK = true;
		return todoOK;
	}

} // Fin de la clase